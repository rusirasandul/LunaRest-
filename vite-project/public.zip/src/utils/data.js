export const questions = [
    {
        question: "Well done for getting started! What would you like us to call you?",
        options: [],

    },
    {
        question: "Select your gender?" ,
        options: ["Male", "Female", "Other"],

    },
    {
        question: "What is your age?" ,
        options: [],
    },
    {
        question: "What year are you currently in at university?",
        options: [
            "1st Year",
            "2nd Year",
            "3rd Year",
            "4th Year",
        ],

    },
    {
        question: "On a typical day in weekdays, how many hours do you sleep? (e.g., 5 hours)",
        options: [],

    },
    {
        question: "On a typical day in weekends, how many hours do you sleep? (e.g., 5 hours)",
        options: [],

    },
    {
        question: "On a typical day in weekdays, how many hours do you spent on studying? (e.g., 5 hours)",
        options: [],
    },
    {
        question: "On a typical day in weekends, how many hours do you spent on studying? (e.g., 5 hours)",
        options: [],
    },
    {
        question: "On a typical day in weekdays, how many hours do you spend on screens for non-study activities? (e.g., on social media, gaming, TV)",
        options: [],
    },
    {
        question: "On a typical day in weekends, how many hours do you spend on screens for non-study activities? (e.g., on social media, gaming, TV)",
        options: [],
    },
    {
        question: "How many caffeinated drinks do you have per day? (coffee, tea, energy drinks)",
        options: [
            "0 (None)",
            "1 drink",
            "2 drinks",
            "3 drinks",
            "4 drinks",
            "5 drinks",
        ],

    },
    {
        question: "How many minutes of vigorous physical activity do you do per day? (e.g., 20 minutes)",
        options: [],
    },
    {
        question: "How would you rate your sleep quality on a scale of 1 to 10? (1 = Very poor, 10 = Excellent)",
        options: [],

    },
    {
        question: "On weekdays, what time do you usually go to sleep? (24-hour format, e.g., 23:00 for 11 PM)",
        options: [],

    },
    {
        question: "On weekdays, what time do you usually wake up? (24-hour format, e.g., 07:00 for 7 AM)",
        options: [],
    },
    {
        question: "On weekends, what time do you usually go to sleep? (24-hour format, e.g., 00:30 for 12:30 AM)",
        options: [],

    },
    {
        question: "On weekends, what time do you usually wake up? (24-hour format, e.g., 09:30 for 9:30 AM)",
        options: [],
    },

];